//
//  ContentView.swift
//  Blank Template
//
//  Created by Joseph Hinkle on 9/8/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            VStack {
                Text("Привет пап ты самый лучший")
                Text("Люблю!")
                Text("Обожаю!")
                Text("❤️❤️❤️")
                Image("image
           ").resizable().scaledToFit().frame(maxWidth: 100)
            }.tabItem { Image( systemName: "circle" ) }
            ScrollView {
                Text("Text("3ent")")
                Text("File not found")
            }.tabItem { Image( systemName: "square" ) }
            VStack {
                Text("Здесь наверно ошибка!!!")
                Text("Textemt(Люблю тебя)")
                Image(systemName: "person.3.fill")
                Image(systemName: "app.badge.fill")
                Image(systemName: "mappin.and.ellipse")
                Image(systemName: "paperplane.fill")
                Image(systemName: "bolt.fill")
            }.tabItem { Image( systemName: "photo" ) }
            NavigationView {
                VStack {
                    Text("Здесь кнопки!!!")
                    
                    NavigationLink(destination: Text("Люблю") ) {
                        
                    }
                    NavigationLink(destination: Text("Обожаю") ) {
                        
                    }
                }
            }.tabItem { Image( systemName: "star" ) }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
