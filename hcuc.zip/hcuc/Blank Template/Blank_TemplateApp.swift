//
//  Blank_TemplateApp.swift
//  Blank Template
//
//  Created by Joseph Hinkle on 9/8/20.
//

import SwiftUI

@main
struct Blank_TemplateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
