This is a basic template which the App Maker app clones as a starting point.

More information at: https://www.appmakerios.com

App Maker download for iOS: https://apps.apple.com/us/app/app-maker-build-native-apps/id1473768340

Testflight download for iOS: http://testflight.apple.com/join/zElad2Q2
